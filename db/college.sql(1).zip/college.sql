-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 21, 2017 at 07:27 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `mobile` char(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `address`, `city`, `mobile`, `email`, `image`) VALUES
(4, 'chandni', 'panchavti   society       ', 'jdfjgh', '98979797', 'krishna@yahoo.com', '6.jpeg'),
(7, 'hetivi', 'tapidarsan', 'jetpur', '57577878', 'ghfgh@f.hjhj', '1.jpeg'),
(8, 'priya', 'jagrutinagar ', 'jetpur', '7896541258', 'patel@gmail.com', '10.jpeg'),
(9, 'sneha', 'gandhiroad ', 'ahemdabad', '8899665547', 'patel@gmail.com', '8.jpeg'),
(27, 'sneha', 'gandhi road ', 'ahemdabad', '7856985588', 'sneha@yahoo.com', '10.jpeg');
